import React, { useContext } from 'react'
import { useState, useEffect } from 'react';

import Axios from "axios";
import { useNavigate } from 'react-router-dom';

import "./notes.css"
import { UserContext } from './UserContext';
function Notes() {
  const { user, setUser } = useContext(UserContext);
  const navigate=useNavigate()
  const [searchtoggle,setSearchToggle]=useState(false)
  const [searchresult,setSearchresult]=useState([])
  const [addnotetitle, addnotetitleSet] = useState("")
  const [addnotecontent, addnotecontentSet] = useState("")
  const [ednote,setEditnote]=useState({});

  const [notes, setNotes] = useState([]);
  const [notetoggle, setnoteTogge] = useState(false)
  const [editadd,seteditadd]=useState("")
  const api = process.env.REACT_APP_URL;
  
  useEffect(() => {
    user===null?navigate("/"):fetchData()
  }, [])
  const fetchData = () => {
    Axios.get(api + `/notes/fetchnotes/${user.id}`).then(async (response) => {
      setNotes(response.data)
    });
  }
  
  const addNotes = (e) => {
    const note = {
      userid: user.id,
      title: addnotetitle,
      date: new Date().toLocaleDateString(),
      content: addnotecontent,
    }
    Axios.post(api + "/notes/addnote", note).then(response => {
      alert(response.data)
      fetchData()
      setnoteTogge(false)
      addnotetitleSet("")
      addnotecontentSet("")
    })
  }
  const deleteanote = (e) => {
    var data=e.target.parentElement.parentElement.firstChild.textContent;
    var delel=notes.find(ele=>ele.notesId==data)
    
    delete delel.notesId
    // console.log(delel)
    Axios.delete(api+`/notes/deletenote/${data}`).then(response=>alert(response.data)).then(()=>fetchData()).then(()=>
      Axios.post(api+"/recycle/addrecycle",delel)
    )
  }
  const editnote = (e) => {
    
    
    Axios.put(api+`/notes/editnote/${ednote.notesId}`,{userid: ednote.userid,
      title: addnotetitle,
      date: ednote.date,
      content: addnotecontent}).then(response=>{
        alert(response.data)
      }).then(()=>{fetchData();setnoteTogge(!notetoggle)})
addnotetitleSet("")
addnotecontentSet("")
  }
  const archive=(e)=>{
      const arc=  e.target.parentElement.previousSibling.textContent;
      console.log(arc)
      const arcdata=notes.find(ele=>ele.notesId==arc)
      delete arcdata.notesId
      console.log(arcdata)
      Axios.delete(api+`/notes/deletenote/${arc}`).then(()=>{
        Axios.post(api+"/archive/addarchive",arcdata).then(()=>{
          alert("Notes archived successfully")
        })
      }).then(()=> fetchData())
      

  }
  const logout=()=>{
   
    return new Promise((resolve) => {
      setUser(null)
      localStorage.setItem('user', JSON.stringify(null));
      
      resolve(); // Resolving the promise after both operations
    }).then(()=>{
      navigate("/")
    })

  }
  return (


    <>
      
      
      {notetoggle ? <div className="editnote">
        <p className="editnotehead">{editadd==="add"?"Add Note":"Edit note"}<img src='./images/close1.jpg' onClick={() => setnoteTogge(!notetoggle)} ></img></p>
        <input onChange={(e) => {
          addnotetitleSet(e.target.value)
        }} type="text" className="titleditnote" placeholder="Enter the title" value={addnotetitle}/>
        <textarea onChange={(e) => {
          addnotecontentSet(e.target.value) 
        }} className="editcontent" placeholder="Write Something...." value={addnotecontent} ></textarea>
        <img src="./images/send1.png" alt="" className="editsendimg" onClick={editadd==="add"?addNotes:editnote} />
      </div> : ""}


      <nav className="nav">
        <div className="container flex">
          <img className='logout' src='./images/logout3.webp' onClick={logout}></img>
          <h1><h4>Hello,</h4> <span> {user===null?"":user.name}</span></h1>
          <div className="search flex">
            <img src="./images/search-outline.svg" alt="" />

            <input type="text" placeholder="Enter title for search..." onChange={(e)=>{
              setSearchToggle(true)
                const val=e.target.value
                 const allval=notes.filter(ele=>(ele.title.toLowerCase()).includes(val.toLowerCase()));
              setSearchresult(allval)
            }}/>
            <button type='submit' className='submitbtn hidden'  >submit</button>

          </div>
          <img className='imu' src='./images/arch.png' onClick={()=>navigate("/archived")}></img>
          <img className='bin' src='./images/bin.webp' onClick={()=>navigate("/recycle")}></img>
          <div className="add-remove flex">
            <a href="" className="add-note flex" onClick={(e) =>{ e.preventDefault();setnoteTogge(!notetoggle);seteditadd("add")}}>
              <div><img src="./images/plus.svg" alt="add-note" /></div>
              <span className='yyy' >Add note</span>
            </a>
          </div>
        </div>

      </nav>

      <div className="notes-container">
        {
         (searchtoggle?searchresult:notes).map((item) => {
            return (
              <div className="notes">

                <span style={{ display: "none" }}>{item.notesId}</span>
                <h3>
                  <div className="pin"><img src="./images/pin2.png" alt="pin-image" /></div>
                  <span>{item.title}</span>
                  <span className='datee'>{item.date}</span>
                  <input type="checkbox" name="delete-note" id="delete-note" />
                  <img src='./images/arch.png' className='arch' onClick={archive}/>
                </h3>
                <textarea value={item.content}></textarea>
                <div className="edit-note flex">
                  <button id="Delete" onClick={deleteanote}>Delete</button>
                  <button id="edit" onClick={(e)=>{
                          setnoteTogge(!notetoggle)
                          seteditadd("edit")
                          var a=e.target.parentElement.parentElement.firstChild.textContent
                          var b=notes.find(ele=>ele.notesId==a)
                          setEditnote(b)
                          addnotetitleSet(b.title)
                          addnotecontentSet(b.content)
                  }}>Edit</button>
                </div>
              </div>
            );
          })
        }
      </div>
      

    </> 
  )
}

export default Notes