import React, { useContext } from 'react'
import { useState,useEffect } from 'react';
import Axios from "axios";
import './recycle.css'
import { UserContext } from './UserContext';
import { useNavigate } from 'react-router-dom';

function Recycle() {
  const navigate=useNavigate()
  const [searchtoggle,setSearchToggle]=useState(false)
  const [searchresult,setSearchresult]=useState([])
  const api = process.env.REACT_APP_URL;
  const { user, setUser } = useContext(UserContext);
  const [notes, setNotes] = useState([]);
  useEffect(() => {
    user===null?navigate("/"):fetchData()
  }, [])
  const fetchData = () => {
    Axios.get(api + `/recycle/fetchrecycle/${user.id}`).then(async (response) => {
      setNotes(response.data)
    });
  }
  const deleteanote = (e) => {
    var data=e.target.parentElement.parentElement.firstChild.textContent;
    
  
    Axios.delete(api+`/recycle/deleterecycle/${data}`).then(response=>alert(response.data)).then(()=>fetchData())
  }
  const retrive = (e) => {
    var data=e.target.parentElement.parentElement.firstChild.textContent;
    var rec=notes.find(ele=>ele.recid==data)
    delete rec.recid
 
    deleteanote(e)
    Axios.post(api + "/notes/addnote", rec).then(response => {
      alert("notes retrived successfully")
    }
    ).then(()=>fetchData())
  }
  const logout=()=>{
   
    return new Promise((resolve) => {
      setUser(null)
      localStorage.setItem('user', JSON.stringify(null));
      
      resolve(); // Resolving the promise after both operations
    }).then(()=>{
      navigate("/")
    })

  }
  return (
    <>
 <nav className="nav">
        <div className="container flex">
          <img className='logout' src='./images/logout3.webp' onClick={logout}></img>
          <h1><h4>Hello,</h4> <span> {user===null?"":user.name}</span></h1>
          <div className="search flex">
            <img src="./images/search-outline.svg" alt="" />

            <input type="text" placeholder="Enter title for search..." onChange={(e)=>{
              setSearchToggle(true)
                const val=e.target.value
                 const allval=notes.filter(ele=>(ele.title.toLowerCase()).includes(val.toLowerCase()));
              setSearchresult(allval)
            }}/>
            <button type='submit' className='submitbtn hidden'  >submit</button>

          </div>
          <img className='imu' src='./images/arch.png' onClick={()=>navigate("/archived")}></img>
          <img className='bin' src='./images/bin.webp' onClick={()=>navigate("/recycle")}></img>
          
        </div>

      </nav>
    <div className="notes-container nsa">
    {
      (searchtoggle?searchresult:notes).map((item)=>{
        return(
                <div className="notes">
                  <span style={{display:"none"}}>{item.recid}</span>
                <h3>
                    <div className="pin"><img src="./images/pin2.png" alt="pin-image"/></div>
                    
                    <span>{item.title}</span>
                    <span className='datee'>{item.date}</span>
        
                    <input type="checkbox" name="delete-note" id="delete-note"/>
                    
                </h3>
                <textarea value={item.content}></textarea>
                <div className="edit-note flex">
                    <button id="Delete" onClick={deleteanote}>Delete</button>
                    <button id="edit" onClick={retrive}>Retrieve</button>
                </div>
            </div>
            
        );
      })
  }
</div>

</>
  )
}

export default Recycle


