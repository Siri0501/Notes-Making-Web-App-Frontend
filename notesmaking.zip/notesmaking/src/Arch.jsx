import React, { useContext } from 'react'
import { useState,useEffect } from 'react';
import Axios from "axios";
import {useNavigate, useLocation} from "react-router-dom"
import './arch.css'
import { UserContext } from './UserContext';
function Arch() {
  const navigate=useNavigate()
  const [searchtoggle,setSearchToggle]=useState(false)
  const [searchresult,setSearchresult]=useState([])
  const api = process.env.REACT_APP_URL;
  const { user, setUser } = useContext(UserContext);
  const [notes, setNotes] = useState([]);
  useEffect(() => {
    user===null?navigate("/"):fetchData()
  }, [])
  const fetchData = () => {
    Axios.get(api + `/archive/fetcharchive/${user.id}`).then(async (response) => {
      setNotes(response.data)
    });
  }
  const deleteanote = (e) => {
    var data=e.target.parentElement.parentElement.firstChild.textContent;
    const rec=notes.find(ele=>ele.arcid==data)
    delete rec.arcid
    Axios.delete(api+`/archive/deletearchive/${data}`).then(()=>{
      Axios.post(api + "/notes/addnote", rec).then(response => {
        alert("notes retrived successfully")
      }).then(()=>fetchData())
    })
  }
  const logout=()=>{
   
    return new Promise((resolve) => {
      setUser(null)
      localStorage.setItem('user', JSON.stringify(null));
      
      resolve(); // Resolving the promise after both operations
    }).then(()=>{
      navigate("/")
    })

  }
    return (
      <>
      
      <nav className="nav">
        <div className="container flex">
          <img className='logout' src='./images/logout3.webp' onClick={logout}></img>
          <h1><h4>Hello,</h4> <span> {user===null?"":user.name}</span></h1>
          <div className="search flex">
            <img src="./images/search-outline.svg" alt="" />

            <input type="text" placeholder="Enter title for search..." onChange={(e)=>{
                setSearchToggle(true)
                const val=e.target.value
                const allval=notes.filter(ele=>(ele.title.toLowerCase()).includes(val.toLowerCase()));
                setSearchresult(allval)
            }}/>
            <button type='submit' className='submitbtn hidden'  >submit</button>

          </div>
          <img className='imu' src='./images/arch.png' onClick={()=>navigate("/archived")}></img>
          <img className='bin' src='./images/bin.webp' onClick={()=>navigate("/recycle")}></img>
          
        </div>

      </nav>
      <div className="notes-container nsa">
      {
       (searchtoggle?searchresult:notes).map((item)=>{
          return(
                  <div className="notes">
                    <span style={{display:"none"}}>{item.arcid}</span>
                  <h3>
                      <div className="pin"><img src="./images/pin2.png" alt="pin-image"/></div>
                      <span>{item.title}</span>
                      <span className='datee'>{item.date}</span>
                      <input type="checkbox" name="delete-note" id="delete-note"/>
                  </h3>
                  <textarea value={item.content}></textarea>
                  <div className="edit-note flex">
                      <button id="dui" onClick={deleteanote}>Retrieve note</button>
                  </div>
              </div>
          );
        })
    }
  </div>
 
  </>
    )
}

export default Arch